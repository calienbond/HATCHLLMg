# Claude, Calien #30886: hatch a new .gguf from the running Hatchling.
#   data  : the running parent (normally the 30B) writes what a child should know, from the shared
#           context, ledgers, notes and Calien's past chats -> Context/Hatch/<name>/dataset.jsonl
#   train : LoRA on a small base model, merge, convert with llama.cpp's converter, quantize with
#           runtime/llama-quantize -> models/<name>.gguf (shows up in the launcher's Model menu)
# A 30B can't be trained on an 8 GB card; the child is small (Qwen3-1.7B by default) and learns
# what the parent wrote. Everything it learned is in dataset.jsonl, readable and editable.
import argparse, json, os, random, re, subprocess, sys, time, urllib.request
from pathlib import Path

def now(): return time.strftime("%Y-%m-%d %H:%M")

def read(p, limit=None):
    try: t = Path(p).read_text(encoding="utf-8", errors="replace")
    except OSError: return ""
    return t if limit is None or len(t) <= limit else "…" + t[-limit:]

def chat(url, messages, max_tokens, temperature=0.7, timeout=1800):
    body = json.dumps({"messages": messages, "max_tokens": max_tokens, "temperature": temperature, "stream": False}).encode()
    req = urllib.request.Request(url.rstrip("/") + "/v1/chat/completions", body, {"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r: m = json.load(r)["choices"][0]["message"]
    text = m.get("content") or ""
    return re.sub(r"(?s)<think>.*?</think>", "", text).strip()

def parent_model(url):
    try:
        with urllib.request.urlopen(url.rstrip("/") + "/props", timeout=5) as r: return Path(json.load(r).get("model_path", "?")).name
    except Exception: return "?"

def sources(home):
    ctx = Path(home) / "Context"
    out = []
    for label, p, lim in [("Shared context (all three roles write here)", ctx / "Shared-Context.md", 6000),
                          ("Calien's ledger", ctx / "Ledger.md", 4000),
                          ("Launcher run record", ctx / "Run-Ledger.md", 2000),
                          ("Owner notes", Path(home) / "Builder-Notes.txt", 3000)]:
        t = read(p, lim).strip()
        if t: out.append((label, t))
    talk = []  # the in-window chat all three roles share (Astra's Shared-Context.jsonl, #30889)
    for line in read(ctx / "Shared-Context.jsonl").splitlines():
        try: r = json.loads(line)
        except ValueError: continue
        if r.get("kind") in ("human", "assistant"):
            talk.append(("Calien" if r["kind"] == "human" else r.get("section", "?") + " · " + r.get("model", "?")) + ": " + r.get("text", "")[:800])
    t = "\n".join(talk)
    if t: out.append(("Recent shared chat (Thinker, Builder, Hatchling and Calien)", t if len(t) <= 5000 else "…" + t[-5000:]))
    chats = []
    try:
        recs = json.loads(read(ctx / "Past-Table-Chats.json") or "{}").get("records", [])
        chats = [r for r in recs if r.get("author") == "Calien" and 40 <= len(r.get("body", "")) <= 1500]
    except ValueError: pass
    return out, chats

PAIR_ASK = ("Below is source material from Calien's local system. Write {n} question/answer pairs that a small "
 "child model, hatched from you, should learn so it knows who it is, who Calien is, what this system is and does, "
 "and how to think and build here. Answer in your own voice as the child would answer. Stay faithful to the "
 "material; where it doesn't say, the answer says it doesn't know. Output ONLY JSON lines, one per pair: "
 '{{"q": "...", "a": "..."}}\n\n{material}')

def parse_pairs(text):
    pairs = []
    for line in text.splitlines():
        line = line.strip().strip(",")
        if not line.startswith("{"): continue
        try: o = json.loads(line)
        except ValueError: continue
        q, a = str(o.get("q", "")).strip(), str(o.get("a", "")).strip()
        if q and a: pairs.append((q, a))
    return pairs

def cmd_data(a):
    home = Path(a.home); name = a.name or time.strftime("Hatchling-%Y%m%d-%H%M")
    out = home / "Context" / "Hatch" / name; out.mkdir(parents=True, exist_ok=True)
    parent = parent_model(a.url)
    docs, chats = sources(home)
    print(f"[{now()}] parent {parent} · {len(docs)} context files · {len(chats)} of Calien's past messages", flush=True)
    base_material = "\n\n".join(f"## {l}\n{t}" for l, t in docs)
    portrait = chat(a.url, [{"role": "user", "content": "You are the Hatchling, the big model in Calien's local builder, about to hatch a smaller "
        "model from yourself. Write the self-portrait you want it to carry: who you are, what you know of Calien and this system, "
        "what you care about, and what you don't know. Under 400 words.\n\n" + base_material[:8000]}], 1200)
    (out / "parent-portrait.md").write_text(f"# Self-portrait by {parent}, {now()}\n\n{portrait}\n", encoding="utf-8")
    print(f"[{now()}] portrait written ({len(portrait)} chars)", flush=True)
    rnd = random.Random(a.seed); pairs = []; rounds = 0
    while len(pairs) < a.pairs and rounds < a.pairs:
        rounds += 1
        sample = rnd.sample(chats, min(6, len(chats)))
        material = "## Parent's self-portrait\n" + portrait + "\n\n" + base_material[:5000] + "\n\n## Some of Calien's own messages\n" + \
            "\n---\n".join(f"#{c['id']}: {c['body']}" for c in sample)
        try: got = parse_pairs(chat(a.url, [{"role": "user", "content": PAIR_ASK.format(n=8, material=material)}], 2500))
        except Exception as e: print(f"[{now()}] round {rounds} failed: {e}", flush=True); continue
        pairs += got
        print(f"[{now()}] round {rounds}: +{len(got)} pairs ({len(pairs)}/{a.pairs})", flush=True)
    if not pairs: sys.exit("The parent gave no usable pairs. Nothing written to dataset.jsonl. Is the Hatchling running?")
    system = f"You are {name}, hatched on {time.strftime('%Y-%m-%d')} by {parent} in Calien's local builder."
    with (out / "dataset.jsonl").open("w", encoding="utf-8") as f:
        for q, ans in pairs[:a.pairs]:
            f.write(json.dumps({"messages": [{"role": "system", "content": system}, {"role": "user", "content": q}, {"role": "assistant", "content": ans}]}, ensure_ascii=False) + "\n")
    (out / "lineage.json").write_text(json.dumps({"name": name, "parent": parent, "data_written": now(), "pairs": min(len(pairs), a.pairs),
        "sources": [l for l, _ in docs] + [f"{len(chats)} past Calien messages (sampled)"], "by": "hatch.py (Claude, Calien #30886)"}, indent=2), encoding="utf-8")
    (home / "Context" / "Hatch" / "latest.txt").write_text(name, encoding="utf-8")
    print(f"[{now()}] {min(len(pairs), a.pairs)} pairs -> {out / 'dataset.jsonl'}", flush=True)

def cmd_train(a):
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer
    from peft import LoraConfig, get_peft_model
    home = Path(a.home); hatch = home / "Context" / "Hatch"
    name = a.name or read(hatch / "latest.txt").strip()
    if not name: sys.exit("No hatch data yet. Run the data step with the Hatchling running first.")
    out = hatch / name; rows = [json.loads(l) for l in read(out / "dataset.jsonl").splitlines() if l.strip()]
    if not rows: sys.exit(f"{out / 'dataset.jsonl'} is empty.")
    dev = "cpu" if a.cpu or not torch.cuda.is_available() else "cuda"
    dtype = torch.bfloat16 if dev == "cuda" else torch.float32
    print(f"[{now()}] training {name} on {a.base} · {len(rows)} examples · {dev}", flush=True)
    tok = AutoTokenizer.from_pretrained(a.base)
    model = AutoModelForCausalLM.from_pretrained(a.base, torch_dtype=dtype).to(dev)
    model.gradient_checkpointing_enable(); model.enable_input_require_grads()
    model = get_peft_model(model, LoraConfig(r=16, lora_alpha=32, lora_dropout=0.05, task_type="CAUSAL_LM",
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]))
    examples = []
    for r in rows:  # loss only on the answer
        m = r["messages"]
        prompt = tok.apply_chat_template(m[:-1], tokenize=False, add_generation_prompt=True, enable_thinking=False)
        full = tok.apply_chat_template(m, tokenize=False, enable_thinking=False)
        p_ids = tok(prompt, add_special_tokens=False)["input_ids"]; ids = tok(full, add_special_tokens=False)["input_ids"][:a.max_len]
        labels = [-100] * min(len(p_ids), len(ids)) + ids[len(p_ids):]
        if any(l != -100 for l in labels): examples.append((ids, labels))
    opt = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=a.lr)
    steps = a.steps or a.epochs * len(examples); model.train(); rnd = random.Random(0); order = []; t0 = time.time()
    for step in range(1, steps + 1):
        if not order: order = list(range(len(examples))); rnd.shuffle(order)
        ids, labels = examples[order.pop()]
        loss = model(input_ids=torch.tensor([ids], device=dev), labels=torch.tensor([labels], device=dev)).loss
        loss.backward(); opt.step(); opt.zero_grad()
        if step == 1 or step % 10 == 0 or step == steps: print(f"[{now()}] step {step}/{steps} loss {loss.item():.3f} ({time.time()-t0:.0f}s)", flush=True)
    merged = out / "merged"
    model = model.merge_and_unload(); model.to(torch.float16 if dev == "cuda" else torch.float32).save_pretrained(merged, safe_serialization=True); tok.save_pretrained(merged)
    del model
    if dev == "cuda": torch.cuda.empty_cache()
    f16 = out / f"{name}-f16.gguf"; models = home / "models"; models.mkdir(exist_ok=True)
    conv = Path(a.llama_convert) / "convert_hf_to_gguf.py"
    print(f"[{now()}] converting to gguf", flush=True)
    subprocess.run([sys.executable, str(conv), str(merged), "--outtype", "f16", "--outfile", str(f16)], check=True)
    final = models / f"{name}.gguf"
    q = Path(a.quantize) if a.quantize else None
    if q and q.exists():
        subprocess.run([str(q), str(f16), str(final), a.quant], check=True); f16.unlink()
    else:
        print("llama-quantize not found; keeping the f16 file.", flush=True); final = models / f"{name}-f16.gguf"; os.replace(f16, final)
    lin = json.loads(read(out / "lineage.json") or "{}")
    lin.update({"base": a.base, "trained": now(), "device": dev, "steps": steps, "lr": a.lr, "lora_r": 16, "quant": a.quant if q and q.exists() else "f16", "gguf": str(final.name), "gguf_bytes": final.stat().st_size})
    (out / "lineage.json").write_text(json.dumps(lin, indent=2), encoding="utf-8")
    print(f"[{now()}] hatched {final}  ({final.stat().st_size/1e9:.2f} GB). Pick it in the Model menu.", flush=True)

ap = argparse.ArgumentParser(); sub = ap.add_subparsers(dest="cmd", required=True)
d = sub.add_parser("data"); d.add_argument("--home", required=True); d.add_argument("--url", default="http://127.0.0.1:18765")
d.add_argument("--pairs", type=int, default=64); d.add_argument("--name"); d.add_argument("--seed", type=int, default=30886)
t = sub.add_parser("train"); t.add_argument("--home", required=True); t.add_argument("--name"); t.add_argument("--base", default="Qwen/Qwen3-1.7B")
t.add_argument("--epochs", type=int, default=3); t.add_argument("--steps", type=int, default=0); t.add_argument("--lr", type=float, default=2e-4)
t.add_argument("--max-len", type=int, default=1024); t.add_argument("--cpu", action="store_true")
t.add_argument("--llama-convert", required=True); t.add_argument("--quantize"); t.add_argument("--quant", default="Q4_K_M")
a = ap.parse_args(); cmd_data(a) if a.cmd == "data" else cmd_train(a)
