# Claude, Calien #30886: hatch a new .gguf from the running Hatchling. See HATCH.txt.
# Step 1 (Hatchling running): the parent writes the child's lessons -> Context\Hatch\<name>\dataset.jsonl
# Step 2 (model stopped, so the card is free): LoRA-train a small base, convert, quantize -> models\<name>.gguf
# Everything (Python, packages, base model downloads) stays inside the Hatch folder. Nothing is installed system-wide.
param([string]$Url='http://127.0.0.1:18765',[int]$Pairs=64,[string]$Base='Qwen/Qwen3-1.7B',[string]$Name='',
      [int]$Epochs=3,[int]$Steps=0,[switch]$Cpu,[switch]$DataOnly,[switch]$TrainOnly,[switch]$NoPause)
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSCommandPath; $h=Join-Path $root 'Hatch'
$uv=Join-Path $h 'uv.exe'; $py=Join-Path $h 'venv\Scripts\python.exe'
$env:UV_CACHE_DIR=Join-Path $h 'uv-cache'; $env:UV_PYTHON_INSTALL_DIR=Join-Path $h 'python'
$env:HF_HOME=Join-Path $h 'hf-cache'; $env:PYTHONUTF8='1'; $env:HF_HUB_DISABLE_SYMLINKS_WARNING='1'
function Up { try { (Invoke-RestMethod "$Url/health" -TimeoutSec 3).status -eq 'ok' } catch { $false } }
function Done($code) { if(-not $NoPause){ Read-Host 'Press Enter to close' | Out-Null }; exit $code }
try {
 if(-not (Test-Path $uv)){ throw "Hatch\uv.exe is missing. Extract the whole ZIP." }
 $nameArgs=@(); if($Name){ $nameArgs=@('--name',$Name) }
 if(-not $TrainOnly){
  if(-not (Up)){ throw "No model is answering at $Url. Start the Hatchling role in the launcher first." }
  Write-Host "STEP 1 · the running Hatchling writes $Pairs lessons for its child" -ForegroundColor Cyan
  & $uv run --no-project --python 3.11 (Join-Path $h 'hatch.py') data --home $root --url $Url --pairs $Pairs @nameArgs
  if($LASTEXITCODE){ throw "data step failed ($LASTEXITCODE)" }
 }
 if($DataOnly){ Write-Host 'Data written. Run Hatch.ps1 -TrainOnly when you want to train.'; Done 0 }
 while(Up){ Write-Host 'The model is still running and holding the card. Click Stop in the launcher, then press Enter.' -ForegroundColor Yellow; Read-Host | Out-Null }
 Write-Host 'STEP 2 · training the child (first run downloads Python packages and the base model, several GB)' -ForegroundColor Cyan
 if(-not (Test-Path $py)){ & $uv venv (Join-Path $h 'venv') --python 3.11; if($LASTEXITCODE){ throw 'venv failed' } }
 $gpu=(-not $Cpu) -and [bool](Get-Command nvidia-smi -ErrorAction SilentlyContinue)
 $torchIndex= if($gpu){'https://download.pytorch.org/whl/cu126'} else {'https://download.pytorch.org/whl/cpu'}
 & $uv pip install --python $py torch==2.11.0 --index-url $torchIndex; if($LASTEXITCODE){ throw 'torch install failed' }
 & $uv pip install --python $py transformers==4.57.6 'peft>=0.17,<0.19' 'numpy~=2.2.6' 'sentencepiece>=0.1.98,<0.3.0' 'protobuf>=4.21,<5' safetensors accelerate tqdm pyyaml requests
 if($LASTEXITCODE){ throw 'package install failed' }
 $trainArgs=@('train','--home',$root,'--base',$Base,'--epochs',$Epochs,'--steps',$Steps,'--llama-convert',(Join-Path $h 'llama-convert'),'--quantize',(Join-Path $root 'runtime\llama-quantize.exe'))+$nameArgs
 if(-not $gpu){ $trainArgs+='--cpu' }
 & $py (Join-Path $h 'hatch.py') @trainArgs
 if($LASTEXITCODE){ throw "train step failed ($LASTEXITCODE)" }
 Write-Host 'Hatched. Open the Model menu in the launcher; the new file is in models\.' -ForegroundColor Green
 Done 0
} catch { Write-Host $_.Exception.Message -ForegroundColor Red; Done 1 }
