$ErrorActionPreference='Stop'
$result=[ordered]@{captured_utc=[DateTime]::UtcNow.ToString('o');computer=$env:COMPUTERNAME;scope='Windows reports only; no pairing, network login, recording or capture';errors=@()}
try {$result.devices=@(Get-PnpDevice -PresentOnly | Select-Object Class,FriendlyName,InstanceId,Status)} catch {$result.errors+=('PnP: '+$_.Exception.Message)}
try {$result.network_adapters=@(Get-NetAdapter -IncludeHidden | Select-Object Name,InterfaceDescription,Status,LinkSpeed)} catch {$result.errors+=('Network: '+$_.Exception.Message)}
try {$result.sound_devices=@(Get-CimInstance Win32_SoundDevice | Select-Object Name,Status,Manufacturer)} catch {$result.errors+=('Sound: '+$_.Exception.Message)}
try {$result.video_controllers=@(Get-CimInstance Win32_VideoController | Select-Object Name,DriverVersion,Status)} catch {$result.errors+=('GPU: '+$_.Exception.Message)}
$result|ConvertTo-Json -Depth 6
