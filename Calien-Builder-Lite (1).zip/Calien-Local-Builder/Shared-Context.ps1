# Astra, Calien #30886. Exact local journal; no inference, training or network calls.
[CmdletBinding()]
param(
 [ValidateSet('append','read','export-training')][string]$Action='read',
 [string]$Root=$PSScriptRoot,
 [ValidateSet('human','assistant','tool','note')][string]$Kind='note',
 [string]$Section='Builder', [string]$Model='', [string]$Text,
 [string]$TextFile, [string]$Prompt, [switch]$TrainingExample,
 [string]$Id=([Guid]::NewGuid().ToString()), [string]$OutputFile
)
$ErrorActionPreference='Stop'
$utf8=New-Object System.Text.UTF8Encoding($false)
$context=Join-Path ([IO.Path]::GetFullPath($Root)) 'Context'
[IO.Directory]::CreateDirectory($context)|Out-Null
$journal=Join-Path $context 'Shared-Context.jsonl'
$lockPath=Join-Path $context 'Shared-Context.lock'
$lock=$null
try {
 for($n=0;$n -lt 100;$n++) {
  try { $lock=[IO.File]::Open($lockPath,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None); break }
  catch [IO.IOException] { Start-Sleep -Milliseconds 50 }
 }
 if($null -eq $lock){throw 'Shared context is busy. Try again; nothing was written.'}
 $rows=@()
 if(Test-Path -LiteralPath $journal){
  $lineNo=0
  foreach($line in [IO.File]::ReadAllLines($journal,$utf8)) {
   $lineNo++
   if(-not $line.Trim()){continue}
   try {$row=ConvertFrom-Json -InputObject $line -ErrorAction Stop}
   catch {throw "Shared context has invalid JSON on line $lineNo. Original retained; no writes made."}
   if($row.schema -ne 'Calien.SharedContext.v1' -or -not $row.id){throw "Invalid shared context record at line $lineNo"}
   $rows+=,$row
  }
 }
 if($Action -eq 'append') {
  if($TextFile){$Text=[IO.File]::ReadAllText([IO.Path]::GetFullPath($TextFile),$utf8)}
  if([string]::IsNullOrWhiteSpace($Text)){throw 'Text or TextFile must contain the exact contribution.'}
  if($TrainingExample -and ($Kind -ne 'assistant' -or [string]::IsNullOrWhiteSpace($Prompt) -or [string]::IsNullOrWhiteSpace($Model))){throw 'A training example needs Kind assistant, Prompt and Model.'}
  $prior=@($rows | Where-Object {$_.id -eq $Id})
  if($prior.Count){
   $p=$prior[0]
   if($p.text -cne $Text -or $p.kind -cne $Kind -or $p.section -cne $Section -or $p.model -cne $Model -or $p.prompt -cne $Prompt -or [bool]$p.training_example -ne [bool]$TrainingExample){throw 'Record ID conflict; original retained.'}
   [ordered]@{ok=$true;id=$Id;replayed=$true}|ConvertTo-Json -Compress
   return
  }
  $row=[ordered]@{schema='Calien.SharedContext.v1';id=$Id;at=[DateTime]::UtcNow.ToString('o');kind=$Kind;section=$Section;model=$Model;text=$Text;prompt=$Prompt;training_example=[bool]$TrainingExample}
  [IO.File]::AppendAllText($journal,($row|ConvertTo-Json -Depth 8 -Compress)+"`n",$utf8)
  [ordered]@{ok=$true;id=$Id;replayed=$false}|ConvertTo-Json -Compress
 } elseif($Action -eq 'read') {
  [ordered]@{schema='Calien.SharedContext.Read.v1';count=$rows.Count;records=@($rows)}|ConvertTo-Json -Depth 12
 } else {
  if(-not $OutputFile){throw 'OutputFile is required; export never overwrites the journal.'}
  $target=[IO.Path]::GetFullPath($OutputFile)
  if($target -eq $journal -or $target -eq $lockPath){throw 'Export must use a separate file.'}
  $selected=@($rows | Where-Object {$_.training_example -eq $true -and $_.kind -eq 'assistant' -and $_.prompt -and $_.model})
  if(-not $selected.Count){throw 'No explicitly selected training examples. No file created.'}
  $lines=@($selected | ForEach-Object {
   [ordered]@{messages=@(@{role='user';content=$_.prompt},@{role='assistant';content=$_.text});source_id=$_.id;source_model=$_.model;source_section=$_.section;source_at=$_.at}|ConvertTo-Json -Depth 8 -Compress
  })
  # CreateNew prevents accidental replacement of an earlier dataset.
  $out=[IO.File]::Open($target,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
  try {$bytes=$utf8.GetBytes(($lines -join "`n")+"`n");$out.Write($bytes,0,$bytes.Length)} finally {$out.Dispose()}
  [ordered]@{ok=$true;examples=$selected.Count;path=$target;status='dataset exported; no weights trained'}|ConvertTo-Json -Compress
 }
} finally {if($null -ne $lock){$lock.Dispose()}}
