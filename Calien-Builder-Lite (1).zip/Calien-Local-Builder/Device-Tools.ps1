# Claude, Calien request #30503. Add-on for Astra's Calien Local Builder (#30501).
# The model calls it through the cmd tool:  powershell -NoProfile -ExecutionPolicy Bypass -File Device-Tools.ps1 <verb> [args]
# Verbs: all | bluetooth | wifi | wifi-nearby | audio | cameras | usb | record-mic <seconds> [out.wav]
param([string]$Verb='all',[string]$A1='',[string]$A2='')
$ErrorActionPreference='Stop'
function Pnp($cls){ @(Get-PnpDevice -PresentOnly -Class $cls -ErrorAction SilentlyContinue | Select-Object FriendlyName,Status,InstanceId) }
function Bluetooth { [ordered]@{
  radios=@(Get-PnpDevice -Class Bluetooth -PresentOnly -ErrorAction SilentlyContinue | Where-Object {$_.InstanceId -notlike 'BTHENUM*' -and $_.InstanceId -notlike 'BTHLE*'} | Select-Object FriendlyName,Status)
  paired_or_known=@(Get-PnpDevice -ErrorAction SilentlyContinue | Where-Object {$_.InstanceId -like 'BTHENUM\*' -or $_.InstanceId -like 'BTHLEDEVICE\*' -or $_.InstanceId -like 'BTHLE\*'} | Select-Object FriendlyName,Status,Present -Unique)
  note='Windows lists paired devices. New nearby devices must be paired once in Settings > Bluetooth.' } }
function Wifi { [ordered]@{ interfaces=(netsh wlan show interfaces) -join "`n"; saved_profiles=@((netsh wlan show profiles) -match ':\s' | ForEach-Object { ($_ -split ':',2)[1].Trim() }) } }
function WifiNearby { (netsh wlan show networks mode=bssid) -join "`n" }
function Audio { [ordered]@{ endpoints=Pnp 'AudioEndpoint'; controllers=@(Get-CimInstance Win32_SoundDevice | Select-Object Name,Status) } }
function Cameras { @(Pnp 'Camera') + @(Pnp 'Image') }
function Usb { @(Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue | Where-Object {$_.InstanceId -like 'USB*'} | Select-Object Class,FriendlyName,Status) }
function RecordMic([int]$sec,[string]$out){
  if($sec -lt 1 -or $sec -gt 600){throw 'seconds must be 1..600'}
  if(-not $out){$out=Join-Path (Get-Location) ('mic-'+(Get-Date -Format yyyyMMdd-HHmmss)+'.wav')}
  $out=[IO.Path]::GetFullPath($out)
  Add-Type -Namespace W -Name Mci -MemberDefinition '[DllImport("winmm.dll",CharSet=CharSet.Unicode)] public static extern int mciSendString(string c,System.Text.StringBuilder r,int n,System.IntPtr h);'
  $go={param($c) $r=[W.Mci]::mciSendString($c,$null,0,[IntPtr]::Zero); if($r -ne 0){throw "mci '$c' failed ($r)"}}
  Write-Host "RECORDING default microphone for $sec s -> $out"
  & $go 'open new type waveaudio alias xi'
  try { & $go 'set xi bitspersample 16 samplespersec 16000 channels 1'; & $go 'record xi'; Start-Sleep -Seconds $sec; & $go 'stop xi'; & $go ('save xi "'+$out+'"') }
  finally { [void][W.Mci]::mciSendString('close xi',$null,0,[IntPtr]::Zero) }
  [ordered]@{saved=$out; bytes=(Get-Item $out).Length; seconds=$sec}
}
$r = switch($Verb){
  'all' {[ordered]@{computer=$env:COMPUTERNAME; bluetooth=Bluetooth; wifi=Wifi; audio=Audio; cameras=Cameras; usb=Usb}}
  'bluetooth'{Bluetooth} 'wifi'{Wifi} 'wifi-nearby'{WifiNearby} 'audio'{Audio} 'cameras'{Cameras} 'usb'{Usb}
  'record-mic'{RecordMic ([int]$A1) $A2}
  default {throw "unknown verb $Verb (all|bluetooth|wifi|wifi-nearby|audio|cameras|usb|record-mic)"}
}
if($r -is [string]){$r}else{$r | ConvertTo-Json -Depth 5}
